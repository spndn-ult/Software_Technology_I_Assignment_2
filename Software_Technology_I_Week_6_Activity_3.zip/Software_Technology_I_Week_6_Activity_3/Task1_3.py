import matplotlib.pyplot as plt
import os
from keras.preprocessing.image import load_img
from keras.preprocessing.image import save_img
from keras.preprocessing.image import img_to_array
img_path = 'Sphaer.PNG'
img = load_img(img_path, color_mode='grayscale')
img_array = img_to_array(img)
save_path_dir = ''
save_filename = 'Sphaer_gray.PNG'
full_save_path = os.path.join(save_path_dir, save_filename)
save_img(full_save_path, img_array)
img = load_img(full_save_path)
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

plt.imshow(img)
plt.axis('off') 
plt.show()
