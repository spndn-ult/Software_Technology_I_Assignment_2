from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.preprocessing.image import array_to_img
img_path = 'Sphaer.PNG'
img = load_img(img_path)
print(type(img))
img_array = img_to_array(img)
print(img_array.dtype)
print(img_array.shape)
img_pil = array_to_img(img_array)
print(type(img))

