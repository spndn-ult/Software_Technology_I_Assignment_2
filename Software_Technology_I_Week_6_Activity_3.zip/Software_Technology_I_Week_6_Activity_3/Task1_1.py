from keras.preprocessing.image import load_img
import matplotlib.pyplot as plt
from PIL import Image

img_path = "Sphaer.PNG"
img = load_img(img_path)
print(type(img))
print(img.format)
print(img.mode)
print(img.size)


plt.imshow(img)
plt.axis('off')
plt.show()
